﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.Panel12 = New System.Windows.Forms.Panel()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Button19 = New System.Windows.Forms.Button()
        Me.TextBox8 = New System.Windows.Forms.TextBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.TextBox9 = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Button18 = New System.Windows.Forms.Button()
        Me.TextBox6 = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.TextBox7 = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Button17 = New System.Windows.Forms.Button()
        Me.TextBox4 = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.TextBox5 = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Button16 = New System.Windows.Forms.Button()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.Panel10 = New System.Windows.Forms.Panel()
        Me.Button14 = New System.Windows.Forms.Button()
        Me.Button15 = New System.Windows.Forms.Button()
        Me.RadioButton7 = New System.Windows.Forms.RadioButton()
        Me.Panel9 = New System.Windows.Forms.Panel()
        Me.Button12 = New System.Windows.Forms.Button()
        Me.Button13 = New System.Windows.Forms.Button()
        Me.RadioButton6 = New System.Windows.Forms.RadioButton()
        Me.Panel8 = New System.Windows.Forms.Panel()
        Me.Button10 = New System.Windows.Forms.Button()
        Me.Button11 = New System.Windows.Forms.Button()
        Me.RadioButton5 = New System.Windows.Forms.RadioButton()
        Me.Panel7 = New System.Windows.Forms.Panel()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.Button9 = New System.Windows.Forms.Button()
        Me.RadioButton4 = New System.Windows.Forms.RadioButton()
        Me.Panel6 = New System.Windows.Forms.Panel()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.RadioButton3 = New System.Windows.Forms.RadioButton()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.RadioButton2 = New System.Windows.Forms.RadioButton()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.RadioButton1 = New System.Windows.Forms.RadioButton()
        Me.Panel11 = New System.Windows.Forms.Panel()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Panel13 = New System.Windows.Forms.Panel()
        Me.TextBox10 = New System.Windows.Forms.TextBox()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Button23 = New System.Windows.Forms.Button()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.Panel16 = New System.Windows.Forms.Panel()
        Me.Button25 = New System.Windows.Forms.Button()
        Me.Button26 = New System.Windows.Forms.Button()
        Me.RadioButton9 = New System.Windows.Forms.RadioButton()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Panel15 = New System.Windows.Forms.Panel()
        Me.Button22 = New System.Windows.Forms.Button()
        Me.Button24 = New System.Windows.Forms.Button()
        Me.RadioButton8 = New System.Windows.Forms.RadioButton()
        Me.TextBox13 = New System.Windows.Forms.TextBox()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.RichTextBox1 = New System.Windows.Forms.RichTextBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.TextBox12 = New System.Windows.Forms.TextBox()
        Me.Button21 = New System.Windows.Forms.Button()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.TextBox11 = New System.Windows.Forms.TextBox()
        Me.Button20 = New System.Windows.Forms.Button()
        Me.TabPage4 = New System.Windows.Forms.TabPage()
        Me.BindingNavigator1 = New System.Windows.Forms.BindingNavigator(Me.components)
        Me.BindingNavigatorAddNewItem = New System.Windows.Forms.ToolStripButton()
        Me.StampDeptDataSetBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.StampDeptDataSet = New KV_COM_LB.StampDeptDataSet()
        Me.BindingNavigatorCountItem = New System.Windows.Forms.ToolStripLabel()
        Me.BindingNavigatorDeleteItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveFirstItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMovePreviousItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorPositionItem = New System.Windows.Forms.ToolStripTextBox()
        Me.BindingNavigatorSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorMoveNextItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveLastItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripComboBox1 = New System.Windows.Forms.ToolStripComboBox()
        Me.NewToolStripButton = New System.Windows.Forms.ToolStripButton()
        Me.toolStripSeparator = New System.Windows.Forms.ToolStripSeparator()
        Me.toolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.btnUpdate = New System.Windows.Forms.Button()
        Me.btnRefresh = New System.Windows.Forms.Button()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.IDDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ToolBarcodeDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ToolUsageCountDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.LastUpdateTimeDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Label_MC_Status = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.AxDBCommManager1 = New AxDATABUILDERAXLibLB.AxDBCommManager()
        Me.BackgroundWorker1 = New System.ComponentModel.BackgroundWorker()
        Me.AxDBDeviceManager1 = New AxDATABUILDERAXLibLB.AxDBDeviceManager()
        Me.AxDBTriggerManager1 = New AxDATABUILDERAXLibLB.AxDBTriggerManager()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.TmrSQL_CheckUsage = New System.Windows.Forms.Timer(Me.components)
        Me.TmrSQL_Update = New System.Windows.Forms.Timer(Me.components)
        Me.Button29 = New System.Windows.Forms.Button()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.txtToolBarCodeCount = New System.Windows.Forms.TextBox()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.TmrToolbarcodeUpdate = New System.Windows.Forms.Timer(Me.components)
        Me.txtToolBarCode = New System.Windows.Forms.TextBox()
        Me.ToolusageTableAdapter = New KV_COM_LB.StampDeptDataSetTableAdapters.ToolusageTableAdapter()
        Me.BtnPrint = New System.Windows.Forms.Button()
        Me.PrintPreviewDialog1 = New System.Windows.Forms.PrintPreviewDialog()
        Me.PrintDocument1 = New System.Drawing.Printing.PrintDocument()
        Me.PrintPreviewControl1 = New System.Windows.Forms.PrintPreviewControl()
        Me.TabControl1.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.Panel12.SuspendLayout()
        Me.Panel10.SuspendLayout()
        Me.Panel9.SuspendLayout()
        Me.Panel8.SuspendLayout()
        Me.Panel7.SuspendLayout()
        Me.Panel6.SuspendLayout()
        Me.Panel5.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.Panel11.SuspendLayout()
        Me.Panel13.SuspendLayout()
        Me.TabPage3.SuspendLayout()
        Me.Panel16.SuspendLayout()
        Me.Panel15.SuspendLayout()
        Me.TabPage4.SuspendLayout()
        CType(Me.BindingNavigator1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.BindingNavigator1.SuspendLayout()
        CType(Me.StampDeptDataSetBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.StampDeptDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage1.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.Panel4.SuspendLayout()
        Me.Panel2.SuspendLayout()
        CType(Me.AxDBCommManager1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.AxDBDeviceManager1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.AxDBTriggerManager1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Controls.Add(Me.TabPage3)
        Me.TabControl1.Controls.Add(Me.TabPage4)
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Location = New System.Drawing.Point(12, 78)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(820, 429)
        Me.TabControl1.TabIndex = 1
        '
        'TabPage2
        '
        Me.TabPage2.BackColor = System.Drawing.Color.Transparent
        Me.TabPage2.Controls.Add(Me.Panel12)
        Me.TabPage2.Controls.Add(Me.Panel10)
        Me.TabPage2.Controls.Add(Me.Panel9)
        Me.TabPage2.Controls.Add(Me.Panel8)
        Me.TabPage2.Controls.Add(Me.Panel7)
        Me.TabPage2.Controls.Add(Me.Panel6)
        Me.TabPage2.Controls.Add(Me.Panel5)
        Me.TabPage2.Controls.Add(Me.Panel3)
        Me.TabPage2.Controls.Add(Me.Panel11)
        Me.TabPage2.Controls.Add(Me.Panel13)
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(812, 403)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "  DEVICES VALUE  "
        '
        'Panel12
        '
        Me.Panel12.BackColor = System.Drawing.Color.DimGray
        Me.Panel12.Controls.Add(Me.Label12)
        Me.Panel12.Controls.Add(Me.Button19)
        Me.Panel12.Controls.Add(Me.TextBox8)
        Me.Panel12.Controls.Add(Me.Label13)
        Me.Panel12.Controls.Add(Me.TextBox9)
        Me.Panel12.Controls.Add(Me.Label10)
        Me.Panel12.Controls.Add(Me.Button18)
        Me.Panel12.Controls.Add(Me.TextBox6)
        Me.Panel12.Controls.Add(Me.Label11)
        Me.Panel12.Controls.Add(Me.TextBox7)
        Me.Panel12.Controls.Add(Me.Label8)
        Me.Panel12.Controls.Add(Me.Button17)
        Me.Panel12.Controls.Add(Me.TextBox4)
        Me.Panel12.Controls.Add(Me.Label9)
        Me.Panel12.Controls.Add(Me.TextBox5)
        Me.Panel12.Controls.Add(Me.Label7)
        Me.Panel12.Controls.Add(Me.Button16)
        Me.Panel12.Controls.Add(Me.TextBox3)
        Me.Panel12.Controls.Add(Me.Label6)
        Me.Panel12.Controls.Add(Me.Label5)
        Me.Panel12.Controls.Add(Me.TextBox1)
        Me.Panel12.Location = New System.Drawing.Point(17, 134)
        Me.Panel12.Name = "Panel12"
        Me.Panel12.Size = New System.Drawing.Size(770, 142)
        Me.Panel12.TabIndex = 12
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label12.Location = New System.Drawing.Point(503, 91)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(109, 13)
        Me.Label12.TabIndex = 21
        Me.Label12.Text = "EM4 WRITE  VALUE"
        '
        'Button19
        '
        Me.Button19.Location = New System.Drawing.Point(618, 105)
        Me.Button19.Name = "Button19"
        Me.Button19.Size = New System.Drawing.Size(86, 23)
        Me.Button19.TabIndex = 20
        Me.Button19.Text = "EM4 WRITE"
        Me.Button19.UseVisualStyleBackColor = True
        '
        'TextBox8
        '
        Me.TextBox8.Location = New System.Drawing.Point(515, 107)
        Me.TextBox8.Name = "TextBox8"
        Me.TextBox8.Size = New System.Drawing.Size(86, 20)
        Me.TextBox8.TabIndex = 19
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label13.Location = New System.Drawing.Point(404, 91)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(93, 13)
        Me.Label13.TabIndex = 18
        Me.Label13.Text = "EM4 CUR VALUE"
        '
        'TextBox9
        '
        Me.TextBox9.Location = New System.Drawing.Point(407, 107)
        Me.TextBox9.Name = "TextBox9"
        Me.TextBox9.Size = New System.Drawing.Size(92, 20)
        Me.TextBox9.TabIndex = 17
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label10.Location = New System.Drawing.Point(501, 43)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(109, 13)
        Me.Label10.TabIndex = 16
        Me.Label10.Text = "EM3 WRITE  VALUE"
        '
        'Button18
        '
        Me.Button18.Location = New System.Drawing.Point(616, 57)
        Me.Button18.Name = "Button18"
        Me.Button18.Size = New System.Drawing.Size(86, 23)
        Me.Button18.TabIndex = 15
        Me.Button18.Text = "EM3 WRITE"
        Me.Button18.UseVisualStyleBackColor = True
        '
        'TextBox6
        '
        Me.TextBox6.Location = New System.Drawing.Point(513, 59)
        Me.TextBox6.Name = "TextBox6"
        Me.TextBox6.Size = New System.Drawing.Size(86, 20)
        Me.TextBox6.TabIndex = 14
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label11.Location = New System.Drawing.Point(402, 43)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(93, 13)
        Me.Label11.TabIndex = 13
        Me.Label11.Text = "EM3 CUR VALUE"
        '
        'TextBox7
        '
        Me.TextBox7.Location = New System.Drawing.Point(405, 59)
        Me.TextBox7.Name = "TextBox7"
        Me.TextBox7.Size = New System.Drawing.Size(92, 20)
        Me.TextBox7.TabIndex = 12
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label8.Location = New System.Drawing.Point(120, 91)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(109, 13)
        Me.Label8.TabIndex = 11
        Me.Label8.Text = "EM2 WRITE  VALUE"
        '
        'Button17
        '
        Me.Button17.Location = New System.Drawing.Point(235, 105)
        Me.Button17.Name = "Button17"
        Me.Button17.Size = New System.Drawing.Size(86, 23)
        Me.Button17.TabIndex = 10
        Me.Button17.Text = "EM2 WRITE"
        Me.Button17.UseVisualStyleBackColor = True
        '
        'TextBox4
        '
        Me.TextBox4.Location = New System.Drawing.Point(132, 107)
        Me.TextBox4.Name = "TextBox4"
        Me.TextBox4.Size = New System.Drawing.Size(86, 20)
        Me.TextBox4.TabIndex = 9
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label9.Location = New System.Drawing.Point(21, 91)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(93, 13)
        Me.Label9.TabIndex = 8
        Me.Label9.Text = "EM2 CUR VALUE"
        '
        'TextBox5
        '
        Me.TextBox5.Location = New System.Drawing.Point(24, 107)
        Me.TextBox5.Name = "TextBox5"
        Me.TextBox5.Size = New System.Drawing.Size(92, 20)
        Me.TextBox5.TabIndex = 7
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label7.Location = New System.Drawing.Point(120, 43)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(109, 13)
        Me.Label7.TabIndex = 6
        Me.Label7.Text = "EM1 WRITE  VALUE"
        '
        'Button16
        '
        Me.Button16.Location = New System.Drawing.Point(235, 57)
        Me.Button16.Name = "Button16"
        Me.Button16.Size = New System.Drawing.Size(86, 23)
        Me.Button16.TabIndex = 5
        Me.Button16.Text = "EM1 WRITE"
        Me.Button16.UseVisualStyleBackColor = True
        '
        'TextBox3
        '
        Me.TextBox3.Location = New System.Drawing.Point(132, 59)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(86, 20)
        Me.TextBox3.TabIndex = 4
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label6.Location = New System.Drawing.Point(21, 43)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(93, 13)
        Me.Label6.TabIndex = 3
        Me.Label6.Text = "EM1 CUR VALUE"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label5.Location = New System.Drawing.Point(169, 1)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(399, 31)
        Me.Label5.TabIndex = 2
        Me.Label5.Text = "EM STATUS (16 UNSIGNED)"
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(24, 59)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(92, 20)
        Me.TextBox1.TabIndex = 0
        '
        'Panel10
        '
        Me.Panel10.BackColor = System.Drawing.Color.LightGray
        Me.Panel10.Controls.Add(Me.Button14)
        Me.Panel10.Controls.Add(Me.Button15)
        Me.Panel10.Controls.Add(Me.RadioButton7)
        Me.Panel10.Location = New System.Drawing.Point(662, 49)
        Me.Panel10.Name = "Panel10"
        Me.Panel10.Size = New System.Drawing.Size(77, 71)
        Me.Panel10.TabIndex = 10
        '
        'Button14
        '
        Me.Button14.BackColor = System.Drawing.Color.DarkGray
        Me.Button14.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button14.Location = New System.Drawing.Point(41, 31)
        Me.Button14.Name = "Button14"
        Me.Button14.Size = New System.Drawing.Size(32, 30)
        Me.Button14.TabIndex = 2
        Me.Button14.Text = "OFF"
        Me.Button14.UseVisualStyleBackColor = False
        '
        'Button15
        '
        Me.Button15.BackColor = System.Drawing.Color.DarkGray
        Me.Button15.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button15.Location = New System.Drawing.Point(3, 31)
        Me.Button15.Name = "Button15"
        Me.Button15.Size = New System.Drawing.Size(32, 30)
        Me.Button15.TabIndex = 1
        Me.Button15.Text = "ON"
        Me.Button15.UseVisualStyleBackColor = False
        '
        'RadioButton7
        '
        Me.RadioButton7.AutoSize = True
        Me.RadioButton7.Location = New System.Drawing.Point(17, 8)
        Me.RadioButton7.Name = "RadioButton7"
        Me.RadioButton7.Size = New System.Drawing.Size(48, 17)
        Me.RadioButton7.TabIndex = 0
        Me.RadioButton7.TabStop = True
        Me.RadioButton7.Text = "MR7"
        Me.RadioButton7.UseVisualStyleBackColor = True
        '
        'Panel9
        '
        Me.Panel9.BackColor = System.Drawing.Color.LightGray
        Me.Panel9.Controls.Add(Me.Button12)
        Me.Panel9.Controls.Add(Me.Button13)
        Me.Panel9.Controls.Add(Me.RadioButton6)
        Me.Panel9.Location = New System.Drawing.Point(562, 49)
        Me.Panel9.Name = "Panel9"
        Me.Panel9.Size = New System.Drawing.Size(77, 71)
        Me.Panel9.TabIndex = 9
        '
        'Button12
        '
        Me.Button12.BackColor = System.Drawing.Color.DarkGray
        Me.Button12.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button12.Location = New System.Drawing.Point(41, 31)
        Me.Button12.Name = "Button12"
        Me.Button12.Size = New System.Drawing.Size(32, 30)
        Me.Button12.TabIndex = 2
        Me.Button12.Text = "OFF"
        Me.Button12.UseVisualStyleBackColor = False
        '
        'Button13
        '
        Me.Button13.BackColor = System.Drawing.Color.DarkGray
        Me.Button13.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button13.Location = New System.Drawing.Point(3, 31)
        Me.Button13.Name = "Button13"
        Me.Button13.Size = New System.Drawing.Size(32, 30)
        Me.Button13.TabIndex = 1
        Me.Button13.Text = "ON"
        Me.Button13.UseVisualStyleBackColor = False
        '
        'RadioButton6
        '
        Me.RadioButton6.AutoSize = True
        Me.RadioButton6.Location = New System.Drawing.Point(17, 8)
        Me.RadioButton6.Name = "RadioButton6"
        Me.RadioButton6.Size = New System.Drawing.Size(48, 17)
        Me.RadioButton6.TabIndex = 0
        Me.RadioButton6.TabStop = True
        Me.RadioButton6.Text = "MR6"
        Me.RadioButton6.UseVisualStyleBackColor = True
        '
        'Panel8
        '
        Me.Panel8.BackColor = System.Drawing.Color.LightGray
        Me.Panel8.Controls.Add(Me.Button10)
        Me.Panel8.Controls.Add(Me.Button11)
        Me.Panel8.Controls.Add(Me.RadioButton5)
        Me.Panel8.Location = New System.Drawing.Point(461, 49)
        Me.Panel8.Name = "Panel8"
        Me.Panel8.Size = New System.Drawing.Size(77, 71)
        Me.Panel8.TabIndex = 8
        '
        'Button10
        '
        Me.Button10.BackColor = System.Drawing.Color.DarkGray
        Me.Button10.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button10.Location = New System.Drawing.Point(41, 31)
        Me.Button10.Name = "Button10"
        Me.Button10.Size = New System.Drawing.Size(32, 30)
        Me.Button10.TabIndex = 2
        Me.Button10.Text = "OFF"
        Me.Button10.UseVisualStyleBackColor = False
        '
        'Button11
        '
        Me.Button11.BackColor = System.Drawing.Color.DarkGray
        Me.Button11.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button11.Location = New System.Drawing.Point(3, 31)
        Me.Button11.Name = "Button11"
        Me.Button11.Size = New System.Drawing.Size(32, 30)
        Me.Button11.TabIndex = 1
        Me.Button11.Text = "ON"
        Me.Button11.UseVisualStyleBackColor = False
        '
        'RadioButton5
        '
        Me.RadioButton5.AutoSize = True
        Me.RadioButton5.Location = New System.Drawing.Point(17, 8)
        Me.RadioButton5.Name = "RadioButton5"
        Me.RadioButton5.Size = New System.Drawing.Size(48, 17)
        Me.RadioButton5.TabIndex = 0
        Me.RadioButton5.TabStop = True
        Me.RadioButton5.Text = "MR5"
        Me.RadioButton5.UseVisualStyleBackColor = True
        '
        'Panel7
        '
        Me.Panel7.BackColor = System.Drawing.Color.LightGray
        Me.Panel7.Controls.Add(Me.Button8)
        Me.Panel7.Controls.Add(Me.Button9)
        Me.Panel7.Controls.Add(Me.RadioButton4)
        Me.Panel7.Location = New System.Drawing.Point(358, 49)
        Me.Panel7.Name = "Panel7"
        Me.Panel7.Size = New System.Drawing.Size(77, 71)
        Me.Panel7.TabIndex = 7
        '
        'Button8
        '
        Me.Button8.BackColor = System.Drawing.Color.DarkGray
        Me.Button8.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button8.Location = New System.Drawing.Point(41, 31)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(32, 30)
        Me.Button8.TabIndex = 2
        Me.Button8.Text = "OFF"
        Me.Button8.UseVisualStyleBackColor = False
        '
        'Button9
        '
        Me.Button9.BackColor = System.Drawing.Color.DarkGray
        Me.Button9.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button9.Location = New System.Drawing.Point(3, 31)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(32, 30)
        Me.Button9.TabIndex = 1
        Me.Button9.Text = "ON"
        Me.Button9.UseVisualStyleBackColor = False
        '
        'RadioButton4
        '
        Me.RadioButton4.AutoSize = True
        Me.RadioButton4.Location = New System.Drawing.Point(17, 8)
        Me.RadioButton4.Name = "RadioButton4"
        Me.RadioButton4.Size = New System.Drawing.Size(48, 17)
        Me.RadioButton4.TabIndex = 0
        Me.RadioButton4.TabStop = True
        Me.RadioButton4.Text = "MR4"
        Me.RadioButton4.UseVisualStyleBackColor = True
        '
        'Panel6
        '
        Me.Panel6.BackColor = System.Drawing.Color.LightGray
        Me.Panel6.Controls.Add(Me.Button6)
        Me.Panel6.Controls.Add(Me.Button7)
        Me.Panel6.Controls.Add(Me.RadioButton3)
        Me.Panel6.Location = New System.Drawing.Point(262, 49)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(77, 71)
        Me.Panel6.TabIndex = 6
        '
        'Button6
        '
        Me.Button6.BackColor = System.Drawing.Color.DarkGray
        Me.Button6.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button6.Location = New System.Drawing.Point(41, 31)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(32, 30)
        Me.Button6.TabIndex = 2
        Me.Button6.Text = "OFF"
        Me.Button6.UseVisualStyleBackColor = False
        '
        'Button7
        '
        Me.Button7.BackColor = System.Drawing.Color.DarkGray
        Me.Button7.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button7.Location = New System.Drawing.Point(3, 31)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(32, 30)
        Me.Button7.TabIndex = 1
        Me.Button7.Text = "ON"
        Me.Button7.UseVisualStyleBackColor = False
        '
        'RadioButton3
        '
        Me.RadioButton3.AutoSize = True
        Me.RadioButton3.Location = New System.Drawing.Point(17, 8)
        Me.RadioButton3.Name = "RadioButton3"
        Me.RadioButton3.Size = New System.Drawing.Size(48, 17)
        Me.RadioButton3.TabIndex = 0
        Me.RadioButton3.TabStop = True
        Me.RadioButton3.Text = "MR3"
        Me.RadioButton3.UseVisualStyleBackColor = True
        '
        'Panel5
        '
        Me.Panel5.BackColor = System.Drawing.Color.LightGray
        Me.Panel5.Controls.Add(Me.Button4)
        Me.Panel5.Controls.Add(Me.Button5)
        Me.Panel5.Controls.Add(Me.RadioButton2)
        Me.Panel5.Location = New System.Drawing.Point(165, 49)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(77, 71)
        Me.Panel5.TabIndex = 5
        '
        'Button4
        '
        Me.Button4.BackColor = System.Drawing.Color.DarkGray
        Me.Button4.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button4.Location = New System.Drawing.Point(41, 31)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(32, 30)
        Me.Button4.TabIndex = 2
        Me.Button4.Text = "OFF"
        Me.Button4.UseVisualStyleBackColor = False
        '
        'Button5
        '
        Me.Button5.BackColor = System.Drawing.Color.DarkGray
        Me.Button5.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button5.Location = New System.Drawing.Point(3, 31)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(32, 30)
        Me.Button5.TabIndex = 1
        Me.Button5.Text = "ON"
        Me.Button5.UseVisualStyleBackColor = False
        '
        'RadioButton2
        '
        Me.RadioButton2.AutoSize = True
        Me.RadioButton2.Location = New System.Drawing.Point(17, 8)
        Me.RadioButton2.Name = "RadioButton2"
        Me.RadioButton2.Size = New System.Drawing.Size(48, 17)
        Me.RadioButton2.TabIndex = 0
        Me.RadioButton2.TabStop = True
        Me.RadioButton2.Text = "MR2"
        Me.RadioButton2.UseVisualStyleBackColor = True
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.Color.LightGray
        Me.Panel3.Controls.Add(Me.Button3)
        Me.Panel3.Controls.Add(Me.Button1)
        Me.Panel3.Controls.Add(Me.RadioButton1)
        Me.Panel3.Location = New System.Drawing.Point(66, 49)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(77, 71)
        Me.Panel3.TabIndex = 3
        '
        'Button3
        '
        Me.Button3.BackColor = System.Drawing.Color.DarkGray
        Me.Button3.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button3.Location = New System.Drawing.Point(41, 31)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(32, 30)
        Me.Button3.TabIndex = 2
        Me.Button3.Text = "OFF"
        Me.Button3.UseVisualStyleBackColor = False
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.DarkGray
        Me.Button1.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.Location = New System.Drawing.Point(3, 31)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(32, 30)
        Me.Button1.TabIndex = 1
        Me.Button1.Text = "ON"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'RadioButton1
        '
        Me.RadioButton1.AutoSize = True
        Me.RadioButton1.Location = New System.Drawing.Point(17, 8)
        Me.RadioButton1.Name = "RadioButton1"
        Me.RadioButton1.Size = New System.Drawing.Size(48, 17)
        Me.RadioButton1.TabIndex = 0
        Me.RadioButton1.TabStop = True
        Me.RadioButton1.Text = "MR1"
        Me.RadioButton1.UseVisualStyleBackColor = True
        '
        'Panel11
        '
        Me.Panel11.BackColor = System.Drawing.Color.DimGray
        Me.Panel11.Controls.Add(Me.Label4)
        Me.Panel11.Location = New System.Drawing.Point(17, 6)
        Me.Panel11.Name = "Panel11"
        Me.Panel11.Size = New System.Drawing.Size(770, 122)
        Me.Panel11.TabIndex = 11
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label4.Location = New System.Drawing.Point(290, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(180, 31)
        Me.Label4.TabIndex = 2
        Me.Label4.Text = "MR STATUS"
        '
        'Panel13
        '
        Me.Panel13.BackColor = System.Drawing.Color.DimGray
        Me.Panel13.Controls.Add(Me.TextBox10)
        Me.Panel13.Controls.Add(Me.Label21)
        Me.Panel13.Controls.Add(Me.Button23)
        Me.Panel13.Controls.Add(Me.Label22)
        Me.Panel13.Controls.Add(Me.Label14)
        Me.Panel13.Controls.Add(Me.TextBox2)
        Me.Panel13.Location = New System.Drawing.Point(17, 282)
        Me.Panel13.Name = "Panel13"
        Me.Panel13.Size = New System.Drawing.Size(449, 104)
        Me.Panel13.TabIndex = 13
        '
        'TextBox10
        '
        Me.TextBox10.Location = New System.Drawing.Point(175, 60)
        Me.TextBox10.Name = "TextBox10"
        Me.TextBox10.Size = New System.Drawing.Size(135, 20)
        Me.TextBox10.TabIndex = 7
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label21.Location = New System.Drawing.Point(172, 43)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(120, 13)
        Me.Label21.TabIndex = 6
        Me.Label21.Text = "EM2000 WRITE  TEXT"
        '
        'Button23
        '
        Me.Button23.Location = New System.Drawing.Point(328, 58)
        Me.Button23.Name = "Button23"
        Me.Button23.Size = New System.Drawing.Size(86, 23)
        Me.Button23.TabIndex = 5
        Me.Button23.Text = "WRITE"
        Me.Button23.UseVisualStyleBackColor = True
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label22.Location = New System.Drawing.Point(21, 43)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(134, 13)
        Me.Label22.TabIndex = 3
        Me.Label22.Text = "EM2000 CURRENT TEXT"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label14.Location = New System.Drawing.Point(69, 0)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(156, 31)
        Me.Label14.TabIndex = 2
        Me.Label14.Text = "TEXT BOX"
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(24, 60)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(134, 20)
        Me.TextBox2.TabIndex = 1
        '
        'TabPage3
        '
        Me.TabPage3.BackColor = System.Drawing.Color.Transparent
        Me.TabPage3.Controls.Add(Me.Panel16)
        Me.TabPage3.Controls.Add(Me.Label17)
        Me.TabPage3.Controls.Add(Me.Panel15)
        Me.TabPage3.Controls.Add(Me.TextBox13)
        Me.TabPage3.Controls.Add(Me.Label19)
        Me.TabPage3.Controls.Add(Me.Label18)
        Me.TabPage3.Controls.Add(Me.RichTextBox1)
        Me.TabPage3.Controls.Add(Me.Label16)
        Me.TabPage3.Controls.Add(Me.TextBox12)
        Me.TabPage3.Controls.Add(Me.Button21)
        Me.TabPage3.Controls.Add(Me.Label15)
        Me.TabPage3.Controls.Add(Me.TextBox11)
        Me.TabPage3.Controls.Add(Me.Button20)
        Me.TabPage3.Location = New System.Drawing.Point(4, 22)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage3.Size = New System.Drawing.Size(812, 403)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "  SQL CHECK TOOL USAGE  "
        '
        'Panel16
        '
        Me.Panel16.BackColor = System.Drawing.Color.LightGray
        Me.Panel16.Controls.Add(Me.Button25)
        Me.Panel16.Controls.Add(Me.Button26)
        Me.Panel16.Controls.Add(Me.RadioButton9)
        Me.Panel16.Location = New System.Drawing.Point(654, 197)
        Me.Panel16.Name = "Panel16"
        Me.Panel16.Size = New System.Drawing.Size(77, 71)
        Me.Panel16.TabIndex = 5
        '
        'Button25
        '
        Me.Button25.BackColor = System.Drawing.Color.DarkGray
        Me.Button25.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button25.Location = New System.Drawing.Point(41, 31)
        Me.Button25.Name = "Button25"
        Me.Button25.Size = New System.Drawing.Size(32, 30)
        Me.Button25.TabIndex = 2
        Me.Button25.Text = "OFF"
        Me.Button25.UseVisualStyleBackColor = False
        '
        'Button26
        '
        Me.Button26.BackColor = System.Drawing.Color.DarkGray
        Me.Button26.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button26.Location = New System.Drawing.Point(3, 31)
        Me.Button26.Name = "Button26"
        Me.Button26.Size = New System.Drawing.Size(32, 30)
        Me.Button26.TabIndex = 1
        Me.Button26.Text = "ON"
        Me.Button26.UseVisualStyleBackColor = False
        '
        'RadioButton9
        '
        Me.RadioButton9.AutoSize = True
        Me.RadioButton9.Location = New System.Drawing.Point(17, 8)
        Me.RadioButton9.Name = "RadioButton9"
        Me.RadioButton9.Size = New System.Drawing.Size(48, 17)
        Me.RadioButton9.TabIndex = 0
        Me.RadioButton9.TabStop = True
        Me.RadioButton9.Text = "MR2"
        Me.RadioButton9.UseVisualStyleBackColor = True
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.Location = New System.Drawing.Point(51, 104)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(222, 20)
        Me.Label17.TabIndex = 13
        Me.Label17.Text = "EM10 UPDATED USAGE :"
        '
        'Panel15
        '
        Me.Panel15.BackColor = System.Drawing.Color.LightGray
        Me.Panel15.Controls.Add(Me.Button22)
        Me.Panel15.Controls.Add(Me.Button24)
        Me.Panel15.Controls.Add(Me.RadioButton8)
        Me.Panel15.Location = New System.Drawing.Point(654, 121)
        Me.Panel15.Name = "Panel15"
        Me.Panel15.Size = New System.Drawing.Size(77, 71)
        Me.Panel15.TabIndex = 4
        '
        'Button22
        '
        Me.Button22.BackColor = System.Drawing.Color.DarkGray
        Me.Button22.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button22.Location = New System.Drawing.Point(41, 31)
        Me.Button22.Name = "Button22"
        Me.Button22.Size = New System.Drawing.Size(32, 30)
        Me.Button22.TabIndex = 2
        Me.Button22.Text = "OFF"
        Me.Button22.UseVisualStyleBackColor = False
        '
        'Button24
        '
        Me.Button24.BackColor = System.Drawing.Color.DarkGray
        Me.Button24.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button24.Location = New System.Drawing.Point(3, 31)
        Me.Button24.Name = "Button24"
        Me.Button24.Size = New System.Drawing.Size(32, 30)
        Me.Button24.TabIndex = 1
        Me.Button24.Text = "ON"
        Me.Button24.UseVisualStyleBackColor = False
        '
        'RadioButton8
        '
        Me.RadioButton8.AutoSize = True
        Me.RadioButton8.Location = New System.Drawing.Point(17, 8)
        Me.RadioButton8.Name = "RadioButton8"
        Me.RadioButton8.Size = New System.Drawing.Size(48, 17)
        Me.RadioButton8.TabIndex = 0
        Me.RadioButton8.TabStop = True
        Me.RadioButton8.Text = "MR1"
        Me.RadioButton8.UseVisualStyleBackColor = True
        '
        'TextBox13
        '
        Me.TextBox13.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox13.Location = New System.Drawing.Point(279, 101)
        Me.TextBox13.Name = "TextBox13"
        Me.TextBox13.Size = New System.Drawing.Size(229, 26)
        Me.TextBox13.TabIndex = 12
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.Location = New System.Drawing.Point(632, 87)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(130, 20)
        Me.Label19.TabIndex = 11
        Me.Label19.Text = "PLC CONTROL"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.Location = New System.Drawing.Point(47, 260)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(146, 20)
        Me.Label18.TabIndex = 9
        Me.Label18.Text = "SQL RESPONSE"
        '
        'RichTextBox1
        '
        Me.RichTextBox1.Location = New System.Drawing.Point(51, 284)
        Me.RichTextBox1.Name = "RichTextBox1"
        Me.RichTextBox1.Size = New System.Drawing.Size(735, 107)
        Me.RichTextBox1.TabIndex = 8
        Me.RichTextBox1.Text = ""
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.Location = New System.Drawing.Point(91, 66)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(182, 20)
        Me.Label16.TabIndex = 5
        Me.Label16.Text = "EM9 NO OF USAGE :"
        '
        'TextBox12
        '
        Me.TextBox12.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox12.Location = New System.Drawing.Point(279, 63)
        Me.TextBox12.Name = "TextBox12"
        Me.TextBox12.Size = New System.Drawing.Size(229, 26)
        Me.TextBox12.TabIndex = 4
        '
        'Button21
        '
        Me.Button21.Location = New System.Drawing.Point(325, 142)
        Me.Button21.Name = "Button21"
        Me.Button21.Size = New System.Drawing.Size(183, 50)
        Me.Button21.TabIndex = 3
        Me.Button21.Text = "CHECK NO OF USAGE"
        Me.Button21.UseVisualStyleBackColor = True
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.Location = New System.Drawing.Point(113, 28)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(160, 20)
        Me.Label15.TabIndex = 2
        Me.Label15.Text = "EM2000 TOOL ID :"
        '
        'TextBox11
        '
        Me.TextBox11.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox11.Location = New System.Drawing.Point(279, 25)
        Me.TextBox11.Name = "TextBox11"
        Me.TextBox11.Size = New System.Drawing.Size(229, 26)
        Me.TextBox11.TabIndex = 1
        '
        'Button20
        '
        Me.Button20.Location = New System.Drawing.Point(325, 218)
        Me.Button20.Name = "Button20"
        Me.Button20.Size = New System.Drawing.Size(183, 50)
        Me.Button20.TabIndex = 0
        Me.Button20.Text = "UPDATE TOOL USAGE"
        Me.Button20.UseVisualStyleBackColor = True
        '
        'TabPage4
        '
        Me.TabPage4.BackColor = System.Drawing.Color.Transparent
        Me.TabPage4.Controls.Add(Me.BindingNavigator1)
        Me.TabPage4.Controls.Add(Me.btnUpdate)
        Me.TabPage4.Controls.Add(Me.btnRefresh)
        Me.TabPage4.Controls.Add(Me.DataGridView1)
        Me.TabPage4.Location = New System.Drawing.Point(4, 22)
        Me.TabPage4.Name = "TabPage4"
        Me.TabPage4.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage4.Size = New System.Drawing.Size(812, 403)
        Me.TabPage4.TabIndex = 3
        Me.TabPage4.Text = "  SQL DATA VIEW  "
        '
        'BindingNavigator1
        '
        Me.BindingNavigator1.AddNewItem = Me.BindingNavigatorAddNewItem
        Me.BindingNavigator1.BindingSource = Me.StampDeptDataSetBindingSource
        Me.BindingNavigator1.CountItem = Me.BindingNavigatorCountItem
        Me.BindingNavigator1.DeleteItem = Me.BindingNavigatorDeleteItem
        Me.BindingNavigator1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BindingNavigatorMoveFirstItem, Me.BindingNavigatorMovePreviousItem, Me.BindingNavigatorSeparator, Me.BindingNavigatorPositionItem, Me.BindingNavigatorCountItem, Me.BindingNavigatorSeparator1, Me.BindingNavigatorMoveNextItem, Me.BindingNavigatorMoveLastItem, Me.BindingNavigatorSeparator2, Me.BindingNavigatorAddNewItem, Me.BindingNavigatorDeleteItem, Me.ToolStripComboBox1, Me.NewToolStripButton, Me.toolStripSeparator, Me.toolStripSeparator1})
        Me.BindingNavigator1.Location = New System.Drawing.Point(3, 3)
        Me.BindingNavigator1.MoveFirstItem = Me.BindingNavigatorMoveFirstItem
        Me.BindingNavigator1.MoveLastItem = Me.BindingNavigatorMoveLastItem
        Me.BindingNavigator1.MoveNextItem = Me.BindingNavigatorMoveNextItem
        Me.BindingNavigator1.MovePreviousItem = Me.BindingNavigatorMovePreviousItem
        Me.BindingNavigator1.Name = "BindingNavigator1"
        Me.BindingNavigator1.PositionItem = Me.BindingNavigatorPositionItem
        Me.BindingNavigator1.Size = New System.Drawing.Size(806, 25)
        Me.BindingNavigator1.TabIndex = 3
        Me.BindingNavigator1.Text = "BindingNavigator1"
        '
        'BindingNavigatorAddNewItem
        '
        Me.BindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorAddNewItem.Image = CType(resources.GetObject("BindingNavigatorAddNewItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorAddNewItem.Name = "BindingNavigatorAddNewItem"
        Me.BindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorAddNewItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorAddNewItem.Text = "Add new"
        '
        'StampDeptDataSetBindingSource
        '
        Me.StampDeptDataSetBindingSource.DataMember = "Toolusage"
        Me.StampDeptDataSetBindingSource.DataSource = Me.StampDeptDataSet
        '
        'StampDeptDataSet
        '
        Me.StampDeptDataSet.DataSetName = "StampDeptDataSet"
        Me.StampDeptDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'BindingNavigatorCountItem
        '
        Me.BindingNavigatorCountItem.Name = "BindingNavigatorCountItem"
        Me.BindingNavigatorCountItem.Size = New System.Drawing.Size(35, 22)
        Me.BindingNavigatorCountItem.Text = "of {0}"
        Me.BindingNavigatorCountItem.ToolTipText = "Total number of items"
        '
        'BindingNavigatorDeleteItem
        '
        Me.BindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorDeleteItem.Image = CType(resources.GetObject("BindingNavigatorDeleteItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorDeleteItem.Name = "BindingNavigatorDeleteItem"
        Me.BindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorDeleteItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorDeleteItem.Text = "Delete"
        '
        'BindingNavigatorMoveFirstItem
        '
        Me.BindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveFirstItem.Image = CType(resources.GetObject("BindingNavigatorMoveFirstItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveFirstItem.Name = "BindingNavigatorMoveFirstItem"
        Me.BindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveFirstItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveFirstItem.Text = "Move first"
        '
        'BindingNavigatorMovePreviousItem
        '
        Me.BindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMovePreviousItem.Image = CType(resources.GetObject("BindingNavigatorMovePreviousItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMovePreviousItem.Name = "BindingNavigatorMovePreviousItem"
        Me.BindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMovePreviousItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMovePreviousItem.Text = "Move previous"
        '
        'BindingNavigatorSeparator
        '
        Me.BindingNavigatorSeparator.Name = "BindingNavigatorSeparator"
        Me.BindingNavigatorSeparator.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorPositionItem
        '
        Me.BindingNavigatorPositionItem.AccessibleName = "Position"
        Me.BindingNavigatorPositionItem.AutoSize = False
        Me.BindingNavigatorPositionItem.Name = "BindingNavigatorPositionItem"
        Me.BindingNavigatorPositionItem.Size = New System.Drawing.Size(50, 23)
        Me.BindingNavigatorPositionItem.Text = "0"
        Me.BindingNavigatorPositionItem.ToolTipText = "Current position"
        '
        'BindingNavigatorSeparator1
        '
        Me.BindingNavigatorSeparator1.Name = "BindingNavigatorSeparator1"
        Me.BindingNavigatorSeparator1.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorMoveNextItem
        '
        Me.BindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveNextItem.Image = CType(resources.GetObject("BindingNavigatorMoveNextItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveNextItem.Name = "BindingNavigatorMoveNextItem"
        Me.BindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveNextItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveNextItem.Text = "Move next"
        '
        'BindingNavigatorMoveLastItem
        '
        Me.BindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveLastItem.Image = CType(resources.GetObject("BindingNavigatorMoveLastItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveLastItem.Name = "BindingNavigatorMoveLastItem"
        Me.BindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveLastItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveLastItem.Text = "Move last"
        '
        'BindingNavigatorSeparator2
        '
        Me.BindingNavigatorSeparator2.Name = "BindingNavigatorSeparator2"
        Me.BindingNavigatorSeparator2.Size = New System.Drawing.Size(6, 25)
        '
        'ToolStripComboBox1
        '
        Me.ToolStripComboBox1.Name = "ToolStripComboBox1"
        Me.ToolStripComboBox1.Size = New System.Drawing.Size(121, 25)
        '
        'NewToolStripButton
        '
        Me.NewToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.NewToolStripButton.Image = CType(resources.GetObject("NewToolStripButton.Image"), System.Drawing.Image)
        Me.NewToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.NewToolStripButton.Name = "NewToolStripButton"
        Me.NewToolStripButton.Size = New System.Drawing.Size(23, 22)
        Me.NewToolStripButton.Text = "&New"
        '
        'toolStripSeparator
        '
        Me.toolStripSeparator.Name = "toolStripSeparator"
        Me.toolStripSeparator.Size = New System.Drawing.Size(6, 25)
        '
        'toolStripSeparator1
        '
        Me.toolStripSeparator1.Name = "toolStripSeparator1"
        Me.toolStripSeparator1.Size = New System.Drawing.Size(6, 25)
        '
        'btnUpdate
        '
        Me.btnUpdate.Location = New System.Drawing.Point(126, 366)
        Me.btnUpdate.Name = "btnUpdate"
        Me.btnUpdate.Size = New System.Drawing.Size(113, 34)
        Me.btnUpdate.TabIndex = 2
        Me.btnUpdate.Text = "Update"
        Me.btnUpdate.UseVisualStyleBackColor = True
        '
        'btnRefresh
        '
        Me.btnRefresh.Location = New System.Drawing.Point(7, 366)
        Me.btnRefresh.Name = "btnRefresh"
        Me.btnRefresh.Size = New System.Drawing.Size(113, 34)
        Me.btnRefresh.TabIndex = 1
        Me.btnRefresh.Text = "Refresh"
        Me.btnRefresh.UseVisualStyleBackColor = True
        '
        'DataGridView1
        '
        Me.DataGridView1.AllowUserToOrderColumns = True
        Me.DataGridView1.AutoGenerateColumns = False
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.IDDataGridViewTextBoxColumn, Me.ToolBarcodeDataGridViewTextBoxColumn, Me.ToolUsageCountDataGridViewTextBoxColumn, Me.LastUpdateTimeDataGridViewTextBoxColumn})
        Me.DataGridView1.DataSource = Me.StampDeptDataSetBindingSource
        Me.DataGridView1.Location = New System.Drawing.Point(7, 45)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(798, 301)
        Me.DataGridView1.TabIndex = 0
        '
        'IDDataGridViewTextBoxColumn
        '
        Me.IDDataGridViewTextBoxColumn.DataPropertyName = "ID"
        Me.IDDataGridViewTextBoxColumn.HeaderText = "ID"
        Me.IDDataGridViewTextBoxColumn.Name = "IDDataGridViewTextBoxColumn"
        Me.IDDataGridViewTextBoxColumn.ReadOnly = True
        '
        'ToolBarcodeDataGridViewTextBoxColumn
        '
        Me.ToolBarcodeDataGridViewTextBoxColumn.DataPropertyName = "ToolBarcode"
        Me.ToolBarcodeDataGridViewTextBoxColumn.HeaderText = "ToolBarcode"
        Me.ToolBarcodeDataGridViewTextBoxColumn.Name = "ToolBarcodeDataGridViewTextBoxColumn"
        '
        'ToolUsageCountDataGridViewTextBoxColumn
        '
        Me.ToolUsageCountDataGridViewTextBoxColumn.DataPropertyName = "ToolUsageCount"
        Me.ToolUsageCountDataGridViewTextBoxColumn.HeaderText = "ToolUsageCount"
        Me.ToolUsageCountDataGridViewTextBoxColumn.Name = "ToolUsageCountDataGridViewTextBoxColumn"
        '
        'LastUpdateTimeDataGridViewTextBoxColumn
        '
        Me.LastUpdateTimeDataGridViewTextBoxColumn.DataPropertyName = "LastUpdateTime"
        Me.LastUpdateTimeDataGridViewTextBoxColumn.HeaderText = "LastUpdateTime"
        Me.LastUpdateTimeDataGridViewTextBoxColumn.Name = "LastUpdateTimeDataGridViewTextBoxColumn"
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.PrintPreviewControl1)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(812, 403)
        Me.TabPage1.TabIndex = 4
        Me.TabPage1.Text = " PRINTER PREVIEW "
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.SystemColors.ActiveBorder
        Me.Panel1.Controls.Add(Me.Panel4)
        Me.Panel1.Controls.Add(Me.Panel2)
        Me.Panel1.Controls.Add(Me.Label3)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Location = New System.Drawing.Point(16, 13)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(779, 59)
        Me.Panel1.TabIndex = 2
        '
        'Panel4
        '
        Me.Panel4.BackColor = System.Drawing.SystemColors.WindowFrame
        Me.Panel4.Controls.Add(Me.Label2)
        Me.Panel4.Location = New System.Drawing.Point(510, 8)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(249, 43)
        Me.Panel4.TabIndex = 3
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.Label2.Location = New System.Drawing.Point(8, 6)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(173, 25)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "-----------------------"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.SystemColors.WindowFrame
        Me.Panel2.Controls.Add(Me.Label_MC_Status)
        Me.Panel2.Location = New System.Drawing.Point(177, 8)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(209, 43)
        Me.Panel2.TabIndex = 3
        '
        'Label_MC_Status
        '
        Me.Label_MC_Status.AutoSize = True
        Me.Label_MC_Status.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_MC_Status.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.Label_MC_Status.Location = New System.Drawing.Point(8, 6)
        Me.Label_MC_Status.Name = "Label_MC_Status"
        Me.Label_MC_Status.Size = New System.Drawing.Size(173, 25)
        Me.Label_MC_Status.TabIndex = 1
        Me.Label_MC_Status.Text = "-----------------------"
        Me.Label_MC_Status.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.SystemColors.ActiveBorder
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(384, 17)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(119, 25)
        Me.Label3.TabIndex = 0
        Me.Label3.Text = "PLC Mode:"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.SystemColors.ActiveBorder
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(4, 17)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(167, 25)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Machine Status:"
        '
        'AxDBCommManager1
        '
        Me.AxDBCommManager1.Enabled = True
        Me.AxDBCommManager1.Location = New System.Drawing.Point(798, 552)
        Me.AxDBCommManager1.Name = "AxDBCommManager1"
        Me.AxDBCommManager1.OcxState = CType(resources.GetObject("AxDBCommManager1.OcxState"), System.Windows.Forms.AxHost.State)
        Me.AxDBCommManager1.Size = New System.Drawing.Size(24, 24)
        Me.AxDBCommManager1.TabIndex = 2
        '
        'BackgroundWorker1
        '
        Me.BackgroundWorker1.WorkerSupportsCancellation = True
        '
        'AxDBDeviceManager1
        '
        Me.AxDBDeviceManager1.Enabled = True
        Me.AxDBDeviceManager1.Location = New System.Drawing.Point(746, 552)
        Me.AxDBDeviceManager1.Name = "AxDBDeviceManager1"
        Me.AxDBDeviceManager1.OcxState = CType(resources.GetObject("AxDBDeviceManager1.OcxState"), System.Windows.Forms.AxHost.State)
        Me.AxDBDeviceManager1.Size = New System.Drawing.Size(24, 24)
        Me.AxDBDeviceManager1.TabIndex = 3
        '
        'AxDBTriggerManager1
        '
        Me.AxDBTriggerManager1.Enabled = True
        Me.AxDBTriggerManager1.Location = New System.Drawing.Point(705, 552)
        Me.AxDBTriggerManager1.Name = "AxDBTriggerManager1"
        Me.AxDBTriggerManager1.OcxState = CType(resources.GetObject("AxDBTriggerManager1.OcxState"), System.Windows.Forms.AxHost.State)
        Me.AxDBTriggerManager1.Size = New System.Drawing.Size(24, 24)
        Me.AxDBTriggerManager1.TabIndex = 4
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(12, 515)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(133, 61)
        Me.Button2.TabIndex = 5
        Me.Button2.Text = "CONNECT TO PLC"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Timer1
        '
        Me.Timer1.Enabled = True
        Me.Timer1.Interval = 10
        '
        'TmrSQL_CheckUsage
        '
        Me.TmrSQL_CheckUsage.Interval = 1000
        '
        'TmrSQL_Update
        '
        Me.TmrSQL_Update.Interval = 1000
        '
        'Button29
        '
        Me.Button29.Location = New System.Drawing.Point(165, 515)
        Me.Button29.Name = "Button29"
        Me.Button29.Size = New System.Drawing.Size(133, 61)
        Me.Button29.TabIndex = 6
        Me.Button29.Text = "COM SELECTION"
        Me.Button29.UseVisualStyleBackColor = True
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(339, 518)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(143, 13)
        Me.Label20.TabIndex = 7
        Me.Label20.Text = "ToolBarcode = ""TOOL1234"""
        '
        'txtToolBarCodeCount
        '
        Me.txtToolBarCodeCount.Location = New System.Drawing.Point(487, 548)
        Me.txtToolBarCodeCount.Name = "txtToolBarCodeCount"
        Me.txtToolBarCodeCount.Size = New System.Drawing.Size(155, 20)
        Me.txtToolBarCodeCount.TabIndex = 8
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(484, 532)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(41, 13)
        Me.Label23.TabIndex = 9
        Me.Label23.Text = " Usage"
        '
        'TmrToolbarcodeUpdate
        '
        Me.TmrToolbarcodeUpdate.Enabled = True
        '
        'txtToolBarCode
        '
        Me.txtToolBarCode.Location = New System.Drawing.Point(487, 513)
        Me.txtToolBarCode.Name = "txtToolBarCode"
        Me.txtToolBarCode.Size = New System.Drawing.Size(140, 20)
        Me.txtToolBarCode.TabIndex = 10
        Me.txtToolBarCode.Text = "TOOL1234"
        '
        'ToolusageTableAdapter
        '
        Me.ToolusageTableAdapter.ClearBeforeFill = True
        '
        'BtnPrint
        '
        Me.BtnPrint.Location = New System.Drawing.Point(342, 546)
        Me.BtnPrint.Name = "BtnPrint"
        Me.BtnPrint.Size = New System.Drawing.Size(75, 23)
        Me.BtnPrint.TabIndex = 11
        Me.BtnPrint.Text = "Print"
        Me.BtnPrint.UseVisualStyleBackColor = True
        '
        'PrintPreviewDialog1
        '
        Me.PrintPreviewDialog1.AutoScrollMargin = New System.Drawing.Size(0, 0)
        Me.PrintPreviewDialog1.AutoScrollMinSize = New System.Drawing.Size(0, 0)
        Me.PrintPreviewDialog1.ClientSize = New System.Drawing.Size(400, 300)
        Me.PrintPreviewDialog1.Document = Me.PrintDocument1
        Me.PrintPreviewDialog1.Enabled = True
        Me.PrintPreviewDialog1.Icon = CType(resources.GetObject("PrintPreviewDialog1.Icon"), System.Drawing.Icon)
        Me.PrintPreviewDialog1.Name = "PrintPreviewDialog1"
        Me.PrintPreviewDialog1.Visible = False
        '
        'PrintDocument1
        '
        '
        'PrintPreviewControl1
        '
        Me.PrintPreviewControl1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PrintPreviewControl1.Document = Me.PrintDocument1
        Me.PrintPreviewControl1.Location = New System.Drawing.Point(3, 3)
        Me.PrintPreviewControl1.Name = "PrintPreviewControl1"
        Me.PrintPreviewControl1.Size = New System.Drawing.Size(806, 397)
        Me.PrintPreviewControl1.TabIndex = 0
        Me.PrintPreviewControl1.Zoom = 0.33618477331052182R
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(844, 580)
        Me.Controls.Add(Me.BtnPrint)
        Me.Controls.Add(Me.txtToolBarCode)
        Me.Controls.Add(Me.Label23)
        Me.Controls.Add(Me.txtToolBarCodeCount)
        Me.Controls.Add(Me.Label20)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.Button29)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.AxDBTriggerManager1)
        Me.Controls.Add(Me.AxDBDeviceManager1)
        Me.Controls.Add(Me.AxDBCommManager1)
        Me.Controls.Add(Me.TabControl1)
        Me.DoubleBuffered = True
        Me.MaximumSize = New System.Drawing.Size(860, 619)
        Me.MinimumSize = New System.Drawing.Size(860, 619)
        Me.Name = "Form1"
        Me.Text = "KV Com Plus Library"
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage2.ResumeLayout(False)
        Me.Panel12.ResumeLayout(False)
        Me.Panel12.PerformLayout()
        Me.Panel10.ResumeLayout(False)
        Me.Panel10.PerformLayout()
        Me.Panel9.ResumeLayout(False)
        Me.Panel9.PerformLayout()
        Me.Panel8.ResumeLayout(False)
        Me.Panel8.PerformLayout()
        Me.Panel7.ResumeLayout(False)
        Me.Panel7.PerformLayout()
        Me.Panel6.ResumeLayout(False)
        Me.Panel6.PerformLayout()
        Me.Panel5.ResumeLayout(False)
        Me.Panel5.PerformLayout()
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        Me.Panel11.ResumeLayout(False)
        Me.Panel11.PerformLayout()
        Me.Panel13.ResumeLayout(False)
        Me.Panel13.PerformLayout()
        Me.TabPage3.ResumeLayout(False)
        Me.TabPage3.PerformLayout()
        Me.Panel16.ResumeLayout(False)
        Me.Panel16.PerformLayout()
        Me.Panel15.ResumeLayout(False)
        Me.Panel15.PerformLayout()
        Me.TabPage4.ResumeLayout(False)
        Me.TabPage4.PerformLayout()
        CType(Me.BindingNavigator1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.BindingNavigator1.ResumeLayout(False)
        Me.BindingNavigator1.PerformLayout()
        CType(Me.StampDeptDataSetBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.StampDeptDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage1.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.Panel4.ResumeLayout(False)
        Me.Panel4.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        CType(Me.AxDBCommManager1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.AxDBDeviceManager1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.AxDBTriggerManager1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents TabControl1 As TabControl
    Friend WithEvents TabPage2 As TabPage
    Friend WithEvents TabPage3 As TabPage
    Friend WithEvents TabPage4 As TabPage
    Friend WithEvents AxDBCommManager1 As AxDATABUILDERAXLibLB.AxDBCommManager
    Friend WithEvents Label_MC_Status As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Panel4 As Panel
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents AxDBDeviceManager1 As AxDATABUILDERAXLibLB.AxDBDeviceManager
    Friend WithEvents AxDBTriggerManager1 As AxDATABUILDERAXLibLB.AxDBTriggerManager
    Friend WithEvents Button2 As Button
    Friend WithEvents Timer1 As Timer
    Public WithEvents BackgroundWorker1 As System.ComponentModel.BackgroundWorker
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents Panel10 As Panel
    Friend WithEvents Button14 As Button
    Friend WithEvents Button15 As Button
    Friend WithEvents RadioButton7 As RadioButton
    Friend WithEvents Panel9 As Panel
    Friend WithEvents Button12 As Button
    Friend WithEvents Button13 As Button
    Friend WithEvents RadioButton6 As RadioButton
    Friend WithEvents Panel8 As Panel
    Friend WithEvents Button10 As Button
    Friend WithEvents Button11 As Button
    Friend WithEvents RadioButton5 As RadioButton
    Friend WithEvents Panel7 As Panel
    Friend WithEvents Button8 As Button
    Friend WithEvents Button9 As Button
    Friend WithEvents RadioButton4 As RadioButton
    Friend WithEvents Panel6 As Panel
    Friend WithEvents Button6 As Button
    Friend WithEvents Button7 As Button
    Friend WithEvents RadioButton3 As RadioButton
    Friend WithEvents Panel5 As Panel
    Friend WithEvents Button4 As Button
    Friend WithEvents Button5 As Button
    Friend WithEvents RadioButton2 As RadioButton
    Friend WithEvents Panel3 As Panel
    Friend WithEvents Button3 As Button
    Friend WithEvents Button1 As Button
    Friend WithEvents RadioButton1 As RadioButton
    Friend WithEvents Panel13 As Panel
    Friend WithEvents Label21 As Label
    Friend WithEvents Button23 As Button
    Friend WithEvents Label22 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents TextBox10 As TextBox
    Friend WithEvents Panel12 As Panel
    Friend WithEvents Label12 As Label
    Friend WithEvents Button19 As Button
    Friend WithEvents TextBox8 As TextBox
    Friend WithEvents Label13 As Label
    Friend WithEvents TextBox9 As TextBox
    Friend WithEvents Label10 As Label
    Friend WithEvents Button18 As Button
    Friend WithEvents TextBox6 As TextBox
    Friend WithEvents Label11 As Label
    Friend WithEvents TextBox7 As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents Button17 As Button
    Friend WithEvents TextBox4 As TextBox
    Friend WithEvents Label9 As Label
    Friend WithEvents TextBox5 As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents Button16 As Button
    Friend WithEvents TextBox3 As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents Panel11 As Panel
    Friend WithEvents Label4 As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents TextBox12 As TextBox
    Friend WithEvents Button21 As Button
    Friend WithEvents Label15 As Label
    Friend WithEvents TextBox11 As TextBox
    Friend WithEvents Button20 As Button
    Friend WithEvents Label18 As Label
    Friend WithEvents RichTextBox1 As RichTextBox
    Friend WithEvents Label19 As Label
    Friend WithEvents Panel16 As Panel
    Friend WithEvents Button25 As Button
    Friend WithEvents Button26 As Button
    Friend WithEvents RadioButton9 As RadioButton
    Friend WithEvents Panel15 As Panel
    Friend WithEvents Button22 As Button
    Friend WithEvents Button24 As Button
    Friend WithEvents RadioButton8 As RadioButton
    Friend WithEvents TmrSQL_CheckUsage As Timer
    Friend WithEvents TmrSQL_Update As Timer
    Friend WithEvents Label17 As Label
    Friend WithEvents TextBox13 As TextBox
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents StampDeptDataSetBindingSource As BindingSource
    Friend WithEvents StampDeptDataSet As StampDeptDataSet
    Friend WithEvents IDDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents ToolBarcodeDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents ToolUsageCountDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents LastUpdateTimeDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents ToolusageTableAdapter As StampDeptDataSetTableAdapters.ToolusageTableAdapter
    Friend WithEvents btnRefresh As Button
    Friend WithEvents btnUpdate As Button
    Friend WithEvents BindingNavigator1 As BindingNavigator
    Friend WithEvents BindingNavigatorAddNewItem As ToolStripButton
    Friend WithEvents BindingNavigatorCountItem As ToolStripLabel
    Friend WithEvents BindingNavigatorDeleteItem As ToolStripButton
    Friend WithEvents BindingNavigatorMoveFirstItem As ToolStripButton
    Friend WithEvents BindingNavigatorMovePreviousItem As ToolStripButton
    Friend WithEvents BindingNavigatorSeparator As ToolStripSeparator
    Friend WithEvents BindingNavigatorPositionItem As ToolStripTextBox
    Friend WithEvents BindingNavigatorSeparator1 As ToolStripSeparator
    Friend WithEvents BindingNavigatorMoveNextItem As ToolStripButton
    Friend WithEvents BindingNavigatorMoveLastItem As ToolStripButton
    Friend WithEvents BindingNavigatorSeparator2 As ToolStripSeparator
    Friend WithEvents ToolStripComboBox1 As ToolStripComboBox
    Friend WithEvents NewToolStripButton As ToolStripButton
    Friend WithEvents toolStripSeparator As ToolStripSeparator
    Friend WithEvents toolStripSeparator1 As ToolStripSeparator
    Friend WithEvents Button29 As Button
    Friend WithEvents Label20 As Label
    Friend WithEvents txtToolBarCodeCount As TextBox
    Friend WithEvents Label23 As Label
    Friend WithEvents TmrToolbarcodeUpdate As Timer
    Friend WithEvents txtToolBarCode As TextBox
    Friend WithEvents BtnPrint As Button
    Friend WithEvents TabPage1 As TabPage
    Friend WithEvents PrintPreviewDialog1 As PrintPreviewDialog
    Friend WithEvents PrintDocument1 As Printing.PrintDocument
    Friend WithEvents PrintPreviewControl1 As PrintPreviewControl
End Class
