﻿Partial Class StampDeptDataSet
End Class

Namespace StampDeptDataSetTableAdapters

    Partial Public Class ToolusageTableAdapter
    End Class
End Namespace
